@echo off
setlocal
cd /d "%~dp0"
set "VSERVO_PYTHON=%~dp0.venv\Scripts\python.exe"
if exist "%VSERVO_PYTHON%" goto ready
set "VSERVO_PYTHON=%~dp0..\..\work\vservo-venv\Scripts\python.exe"
if exist "%VSERVO_PYTHON%" goto ready
call "%~dp0setup.cmd"
if errorlevel 1 exit /b 1
set "VSERVO_PYTHON=%~dp0.venv\Scripts\python.exe"
:ready
if /i "%~1"=="--verify" goto verify
"%VSERVO_PYTHON%" "%~dp0app.py" %*
if errorlevel 1 goto failure
exit /b 0
:verify
"%VSERVO_PYTHON%" "%~dp0verify.py"
if errorlevel 1 goto failure
exit /b 0
:failure
echo.
echo VServo could not finish. Please keep the error above for troubleshooting.
pause
exit /b 1
