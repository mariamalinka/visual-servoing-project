"""Stage 1 desktop lab: real MuJoCo rendering with manual velocity jogging."""
from __future__ import annotations

import argparse
import json
import time
from datetime import datetime

import cv2
import numpy as np
from PIL import Image

from simulation import ROOT, Simulation

WINDOW = "VServo | Step 1 - Robot and wrist camera"
# Colors are RGB, because MuJoCo returns RGB.
BG = (16, 22, 31)
PANEL = (26, 34, 46)
TEXT = (225, 234, 243)
MUTED = (151, 169, 188)
TEAL = (77, 214, 192)
AMBER = (246, 194, 102)
JOINT_NAMES = ["Base yaw", "Shoulder", "Elbow", "Wrist roll", "Wrist pitch", "Tool roll"]


def label(canvas: np.ndarray, text: str, x: int, y: int,
          size: float = 0.5, color: tuple = TEXT, weight: int = 1) -> None:
    cv2.putText(canvas, text, (x, y), cv2.FONT_HERSHEY_SIMPLEX, size,
                color, weight, cv2.LINE_AA)


class Lab:
    def __init__(self, sim: Simulation) -> None:
        self.sim = sim
        self.selected = 0
        self.paused = False
        self.demo = False
        self.demo_start = 0.0
        self.pulse_end = 0.0
        self.buttons: list[tuple[tuple[int, int, int, int], str]] = []
        self.message = "Try J1 +, then Reset. Watch the target shift in the wrist image."
        self.last_rgb: np.ndarray | None = None
        self.demo_origin = sim.data.qpos.copy()

    def reset(self) -> None:
        self.sim.reset()
        self.demo = False
        self.paused = False
        self.pulse_end = 0
        self.message = "Home pose restored. The target is visible through the wrist camera."

    def jog(self, joint: int, direction: int) -> None:
        self.selected = joint
        self.demo = False
        self.paused = False
        command = np.zeros(6)
        command[joint] = direction * self.sim.config["jog_velocity_rad_s"]
        self.sim.command_velocity(command)
        self.pulse_end = self.sim.data.time + self.sim.config["jog_duration_s"]
        self.message = f"J{joint + 1}: {command[joint]:+.2f} rad/s for {self.sim.config['jog_duration_s']:.2f} s."

    def toggle_demo(self) -> None:
        if self.demo:
            self.stop()
        else:
            self.reset()
            self.demo = True
            self.demo_start = self.sim.data.time
            self.demo_origin = self.sim.data.qpos.copy()
            self.message = "Scripted motion demo. Image-based alignment begins in step 2."

    def stop(self) -> None:
        self.demo = False
        self.pulse_end = 0
        self.sim.command_velocity(np.zeros(6))
        self.message = "Zero joint velocity commanded."

    def toggle_pause(self) -> None:
        self.paused = not self.paused
        # Pausing cancels the current pulse and the demo; resuming is stationary.
        self.stop()
        self.message = "Simulation paused." if self.paused else "Simulation resumed."

    def advance(self, seconds: float) -> None:
        if self.paused:
            return
        if self.demo:
            t = self.sim.data.time - self.demo_start
            amplitudes = np.array([0.026, 0.016, 0.020, 0.025, 0.016, 0.03])
            frequencies = np.array([0.8, 0.6, 0.7, 0.6, 0.9, 0.7])
            target = self.demo_origin + amplitudes * np.sin(frequencies * t)
            feedforward = amplitudes * frequencies * np.cos(frequencies * t)
            self.sim.command_velocity(feedforward + 3 * (target - self.sim.data.qpos))
        elif self.pulse_end > self.sim.data.time:
            # Split at the pulse deadline so one click has a fixed duration.
            pulse_duration = min(seconds, self.pulse_end - self.sim.data.time)
            self.sim.advance(pulse_duration)
            seconds -= pulse_duration
            if self.sim.data.time >= self.pulse_end - self.sim.model.opt.timestep:
                self.sim.command_velocity(np.zeros(6))
                self.pulse_end = 0
        else:
            self.sim.command_velocity(np.zeros(6))
        if seconds > 1e-10:
            self.sim.advance(seconds)

    def button(self, canvas: np.ndarray, rect: tuple[int, int, int, int],
               text: str, action: str, active: bool = False) -> None:
        x, y, w, h = rect
        cv2.rectangle(canvas, (x, y), (x+w, y+h), TEAL if active else PANEL, -1)
        label(canvas, text, x+12, y+h//2+5, color=BG if active else TEXT)
        self.buttons.append((rect, action))

    def draw(self) -> np.ndarray:
        canvas = np.full((766, 1200, 3), BG, dtype=np.uint8)
        self.buttons.clear()
        label(canvas, "VServo", 24, 36, 0.95, TEAL, 2)
        label(canvas, "STEP 01 / SIMULATED ROBOT + WRIST CAMERA", 24, 61, 0.44, MUTED)
        self.button(canvas, (786, 23, 118, 34), "Reset [R]", "reset")
        self.button(canvas, (916, 23, 118, 34), "Demo [M]", "demo", self.demo)
        self.button(canvas, (1046, 23, 130, 34), "Play" if self.paused else "Pause", "pause", self.paused)
        label(canvas, "WORLD VIEW", 24, 92, 0.46, MUTED)
        label(canvas, "WRIST CAMERA / 640 x 480", 608, 92, 0.46, MUTED)
        rgb = self.sim.image()
        self.last_rgb = rgb
        world = self.sim.image("world")
        annotated = rgb.copy()
        corners = self.sim.marker_corners(rgb)
        if corners is not None:
            cv2.polylines(annotated, [corners.astype(np.int32)], True, TEAL, 2, cv2.LINE_AA)
            for i, corner in enumerate(corners):
                cv2.circle(annotated, tuple(corner.astype(int)), 4, TEAL, -1)
                label(annotated, str(i), int(corner[0])+7, int(corner[1])-6, 0.45, TEAL)
        cv2.drawMarker(annotated, (320, 240), (230, 163, 81), cv2.MARKER_CROSS, 18, 1)
        canvas[102:528, 24:592] = cv2.resize(world, (568, 426))
        canvas[102:528, 608:1176] = cv2.resize(annotated, (568, 426))
        state = "PAUSED" if self.paused else "DEMO" if self.demo else "MANUAL"
        label(canvas, f"{state}   |   simulation time {self.sim.data.time:7.2f} s", 24, 551, 0.45, TEAL)
        if corners is None:
            label(canvas, "Target outside view / not detected - Reset to recover", 608, 551, 0.42, AMBER)
        else:
            centroid = corners.mean(axis=0)
            label(canvas, f"Marker 7 detected   |   center ({centroid[0]:.1f}, {centroid[1]:.1f}) px",
                  608, 551, 0.45, TEAL)
        cv2.line(canvas, (24, 571), (1176, 571), PANEL, 1)
        label(canvas, "JOINT JOG / EACH CLICK SENDS A SHORT VELOCITY COMMAND", 24, 594, 0.43, MUTED)
        self.button(canvas, (1046, 580, 130, 28), "Stop", "stop")
        for i, name in enumerate(JOINT_NAMES):
            col, row = i // 3, i % 3
            x, y = 24 + 584 * col, 615 + 37 * row
            color = TEAL if i == self.selected else TEXT
            label(canvas, f"J{i+1}  {name}", x, y+21, 0.5, color)
            label(canvas, f"{np.rad2deg(self.sim.data.qpos[i]):+7.1f} deg", x+250, y+21, 0.47, MUTED)
            self.button(canvas, (x+406, y, 65, 29), "-", f"jog:{i}:-1")
            self.button(canvas, (x+483, y, 65, 29), "+", f"jog:{i}:1")
        label(canvas, self.message, 24, 738, 0.44, MUTED)
        label(canvas, "1-6: select joint   A/D: jog   Space: pause   S: save camera   Esc: quit", 24, 758, 0.39, MUTED)
        return canvas

    def on_mouse(self, event: int, x: int, y: int, flags: int, param: object) -> None:
        if event != cv2.EVENT_LBUTTONDOWN:
            return
        for (bx, by, w, h), action in self.buttons:
            if bx <= x <= bx+w and by <= y <= by+h:
                if action.startswith("jog:"):
                    _, joint, direction = action.split(":")
                    self.jog(int(joint), int(direction))
                else:
                    {"reset": self.reset, "demo": self.toggle_demo,
                     "pause": self.toggle_pause, "stop": self.stop}[action]()
                break

    def save(self) -> None:
        if self.last_rgb is None:
            return
        directory = ROOT / "captures" / datetime.now().strftime("%Y%m%d-%H%M%S-%f")
        directory.mkdir(parents=True)
        Image.fromarray(self.last_rgb).save(directory / "wrist.png")
        metadata = {"simulation_time_s": self.sim.data.time,
                    "qpos_rad": self.sim.data.qpos.tolist(),
                    "K": self.sim.camera_intrinsics().tolist(),
                    "world_from_optical": self.sim.camera_pose().tolist()}
        (directory / "camera.json").write_text(json.dumps(metadata, indent=2))
        self.message = "Saved raw wrist.png and camera.json in captures/."

    def run(self) -> None:
        cv2.namedWindow(WINDOW, cv2.WINDOW_NORMAL | cv2.WINDOW_KEEPRATIO)
        cv2.resizeWindow(WINDOW, 1200, 766)
        cv2.setMouseCallback(WINDOW, self.on_mouse)
        period = 1 / self.sim.config["camera_hz"]
        try:
            while True:
                start = time.perf_counter()
                self.advance(period)
                cv2.imshow(WINDOW, cv2.cvtColor(self.draw(), cv2.COLOR_RGB2BGR))
                key = cv2.waitKeyEx(max(1, int((period - (time.perf_counter()-start))*1000)))
                if key == 27 or cv2.getWindowProperty(WINDOW, cv2.WND_PROP_VISIBLE) < 1:
                    break
                if ord("1") <= key <= ord("6"):
                    self.selected = key - ord("1")
                elif key in (ord("a"), ord("A")):
                    self.jog(self.selected, -1)
                elif key in (ord("d"), ord("D")):
                    self.jog(self.selected, 1)
                elif key in (ord("r"), ord("R")):
                    self.reset()
                elif key in (ord("m"), ord("M")):
                    self.toggle_demo()
                elif key == 32:
                    self.toggle_pause()
                elif key in (ord("s"), ord("S")):
                    self.save()
        finally:
            cv2.destroyAllWindows()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--snapshot", action="store_true", help="Render a preview without opening a window")
    args = parser.parse_args()
    with Simulation() as sim:
        lab = Lab(sim)
        if args.snapshot:
            Image.fromarray(lab.draw()).save(ROOT / "preview.png")
        else:
            lab.run()


if __name__ == "__main__":
    main()
