# VServo - step 1

A working, fully simulated six-joint robot arm, wrist camera and ArUco target.
Runs locally on Windows with MuJoCo and Python. No physical camera, robot,
Arduino or Raspberry Pi is required.

![Simulation preview](preview.png)

## Start on this computer

1. Double-click **run.cmd** in this folder.
2. The left image shows the robot; the right image is its wrist camera.
3. Click **+** next to **J1 Base yaw**. The arm rotates and the target shifts
   across the camera image. Each click commands 0.18 rad/s for 0.25 simulated seconds.
4. Click **Reset** to return to the starting pose.
5. Click **Demo** for gentle scripted motion of all six joints. Click **Stop**
   to command zero velocity.

This computer is already set up. The launcher uses the project-local environment
in `../../work/vservo-venv`. The first run on another computer sets up `.venv`
inside this folder instead. Keep this folder together; do not move only run.cmd.

**Stage 1 is manual motion.** The demo is a scripted joint trajectory. Automatic
alignment using image error will be implemented in step 2.

## Controls

| Control | Result |
|---|---|
| Joint - / + buttons | Send a short negative / positive velocity pulse |
| 1 through 6 | Select a joint for keyboard jogging |
| A / D | Jog the selected joint negatively / positively |
| R / Reset | Restore the home pose and reset simulation time |
| M / Demo | Toggle the scripted motion demo; enabling it first resets home |
| Space / Pause | Pause or resume; cancels active motion commands |
| Stop | Command zero velocity; actuators brake the motion |
| S | Save an unannotated camera image and metadata under captures/ |
| Esc / close window | Exit |

The green outline comes from **OpenCV detecting pixels in the rendered image**.
The orange cross marks the image center. If the target leaves the view, Reset
recovers the starting pose. The image shown on screen is scaled to fit; saved
camera frames retain their 640 x 480 resolution.

## Reproduce on another Windows computer

Install 64-bit Python 3.12, then run **setup.cmd**, followed by **run.cmd**.
The initial setup downloads the pinned dependencies. Subsequent runs work offline.
An OpenGL-capable graphics driver is needed for camera rendering.

Equivalent terminal commands from this folder:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe app.py
```

The launcher does not change system Python or require administrator privileges.
This version uses MuJoCo in place of the original Gazebo/ROS 2 stack, as agreed
for the Windows setup. It does not implement ROS topics or ros2_control.

## Verify step 1

```powershell
.\run.cmd --verify
```

This runs without the desktop control window, but still renders actual camera
images through OpenGL. It writes `verification/results.json` and before/after
images, exiting with a failure if an acceptance criterion fails.

Checks performed:

- All six joints respond to velocity actuator commands.
- The camera moves with the wrist, and the target shifts in the rendered image.
- The target is detected from camera pixels before and after the test movement.
- The gravity-compensated arm remains stationary under a zero velocity command.
- Reset restores the same camera pose and pixel-identical initial image.
- A manual jog stops automatically after its short pulse.

Recorded on this computer (see results.json for the reproducible measurements):

| Test | Result |
|---|---:|
| J1 command | 0.15 rad/s for 0.5 s, then 0.25 s braking |
| J1 rotation | 4.21 degrees |
| Wrist camera translation | 5.14 cm |
| Detected marker center displacement | 90.50 pixels |
| All six actuator responses | Passed |
| Repeatable reset and automatic jog stop | Passed |

These measurements establish motion and camera coupling, not visual-servoing
accuracy or convergence.

## Files to work with next

| File | Purpose |
|---|---|
| scene.xml | Robot geometry, joints, velocity actuators, camera and target |
| config.json | Camera sampling, jog velocity and duration, marker settings |
| simulation.py | Physics stepping, RGB images, camera calibration and command interface |
| app.py | Desktop controls and the two rendered views |
| verify.py | Reproducible acceptance checks and result export |
| requirements.txt | Tested, pinned dependencies |
| verification/ | Measurements and before/after camera images |

The API for step 2 is deliberately small:

```python
import numpy as np
from simulation import Simulation

with Simulation() as sim:
    rgb = sim.image()                 # RGB uint8, 480 x 640 x 3
    corners = sim.marker_corners(rgb) # Four image points, or None
    K = sim.camera_intrinsics()       # Pinhole calibration matrix
    sim.command_velocity(np.array([0.1, 0, 0, 0, 0, 0]))
    sim.advance(1 / 30)               # Advance in simulated seconds
```

Coordinates use meters, radians and seconds. `camera_pose()` returns the
world-from-optical transform: optical +X right, +Y down, +Z forward. It is
simulator ground truth for kinematics and evaluation, not a replacement for
image-based perception. MuJoCo's rendering convention is converted explicitly.

The physics runs at 500 Hz in simulated time, with 30 Hz camera samples in the
desktop app. If rendering is slow, wall-clock playback slows; 30 real-time FPS
is not guaranteed. Motion is integrated through MuJoCo velocity actuators;
joint positions are assigned only during explicit reset.

The target is a 0.32 m board with a 0.24 m ArUco marker (DICT_4X4_50, ID 7).
The generated texture compensates for the negative-X box face's mirrored UV
mapping. The camera image itself is never mirrored to make detection succeed.

## Scope and next step

This is an original teaching-arm model, not a calibrated commercial robot.
It uses ideal gravity compensation, simple geometry and disabled robot
collisions. Lighting is fixed; camera distortion, latency and noise are absent.
These are declared starting assumptions for the later robustness experiments.

Next: implement the point-feature interaction matrix, verify it against finite
differences, map the camera twist to joint velocities, then close the IBVS loop.

Documentation used:

- [MuJoCo Python bindings](https://mujoco.readthedocs.io/en/stable/python.html)
- [MuJoCo model and actuator XML reference](https://mujoco.readthedocs.io/en/stable/XMLreference.html)
- [OpenCV ArUco detection](https://docs.opencv.org/4.x/d5/dae/tutorial_aruco_detection.html)
